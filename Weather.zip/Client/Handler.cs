﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;

namespace Client
{
    class Handler
    {
        private WeatherNamespace.IWeather weather;
        private ChannelFactory<WeatherNamespace.IWeather> scf;
        public Handler()
        {
            var binding = new NetTcpBinding();
            binding.OpenTimeout = new TimeSpan(2, 0, 0);
            binding.CloseTimeout = new TimeSpan(2, 0, 0);
            binding.SendTimeout = new TimeSpan(2, 0, 0);
            binding.ReceiveTimeout = new TimeSpan(2, 0, 0);
            binding.MaxReceivedMessageSize = 81280000;
            binding.Security.Mode = SecurityMode.Message;
            this.scf = new ChannelFactory<WeatherNamespace.IWeather>(binding, "net.tcp://localhost:8001");
            this.weather = scf.CreateChannel();          
        }
        public string Name
        {
            get
            {
                return this.weather.GetTemperature();
            }
        }
    }
}
