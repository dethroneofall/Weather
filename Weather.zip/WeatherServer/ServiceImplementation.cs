﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using WeatherNamespace;
using System.Xml;

namespace WeatherServer
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single, IncludeExceptionDetailInFaults = true, UseSynchronizationContext = false)]
    class ServiceImplementation : WeatherNamespace.IWeather
    {
        private XmlDocument doc;
        public ServiceImplementation()
        {
            doc = new XmlDocument();

            Task.Run(() =>
            {
                doc.Load("https://xml.meteoservice.ru/export/gismeteo/point/55.xml");
            });
        }
        string IWeather.GetTemperature()
        {
            ParceXml();
            return "Hello";
        }
        private void ParceXml()
        {
            Console.Write(doc.InnerXml);
        }
    }
}
