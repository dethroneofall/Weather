﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;

namespace WeatherServer
{
    class Handler
    {
        private NetTcpBinding binding;
        private ServiceImplementation implementation;
        public Handler()
        {
            this.implementation = new ServiceImplementation();
            ServiceHost host = new ServiceHost(this.implementation);
            this.binding = new NetTcpBinding();
            binding.OpenTimeout = new TimeSpan(2, 0, 0);
            binding.CloseTimeout = new TimeSpan(2, 0, 0);
            binding.SendTimeout = new TimeSpan(2, 0, 0);
            binding.ReceiveTimeout = new TimeSpan(2, 0, 0);
            binding.MaxReceivedMessageSize = 81280000;
            binding.Security.Mode = SecurityMode.Message;
            host.AddServiceEndpoint(typeof(WeatherNamespace.IWeather),
                binding, "net.tcp://localhost:8001");
            host.Open();
        }
    }
}
